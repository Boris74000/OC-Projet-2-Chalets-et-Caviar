<?php
defined( 'ABSPATH' ) or die( "you do not have acces to this page!" );
